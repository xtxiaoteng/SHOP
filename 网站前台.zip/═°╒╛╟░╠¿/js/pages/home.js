$(function() {
    $('input,textarea').placeholder();
})